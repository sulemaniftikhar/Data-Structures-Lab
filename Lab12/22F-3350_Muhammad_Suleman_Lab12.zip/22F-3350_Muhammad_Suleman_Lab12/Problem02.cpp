//#include <iostream>
//
//using namespace std;
//
//void heapify(int arr[], int n, int i)
//{
//	int parent = i;
//	int left = 2 * i + 1;
//	int right = 2 * i + 2;
//
//
//	if (left < n && arr[left] > arr[parent])
//	{
//		parent = left;
//	}
//
//	if (right < n && arr[right] > arr[parent])
//	{
//		parent = right;
//	}
//
//	if (parent != i)
//	{
//		swap(arr[i], arr[parent]);
//		heapify(arr, n, parent);
//	}
//}
//
//void heapSort(int arr[], int n)
//{
//	for (int i = n / 2 - 1; i >= 0; i--)
//		heapify(arr, n, i);
//
//	for (int i = n - 1; i >= 0; i--)
//	{
//		swap(arr[0], arr[i]);
//		heapify(arr, i, 0);
//	}
//}
//
//void printArray(int arr[], int n)
//{
//	for (int i = 0; i < n; ++i)
//	{
//		cout << arr[i] << "  ";
//	}
//	cout << endl;
//}
//
//int main()
//{
//	int arr[] = { 90,80,70,60,50,40,30,20,10 };
//	int n = 9;
//
//	for (int i = n / 2 - 1; i >= 0; i--) {
//		heapify(arr, n, i);
//	}
//
//	cout << "After heapifying array: ";
//	printArray(arr, n);
//
//
//	heapSort(arr, n);
//	cout << "Sorted array: ";
//	printArray(arr, n);
//
//	system("pause");
//	return 0;
//}