// #include <iostream>

// using namespace std;

// class Task
// {
// public:
//     int id;
//     int priority;
//     int executionTime;
//     Task *next;

//     Task(int id, int priority, int executionTime)
//         : id(id), priority(priority), executionTime(executionTime), next(nullptr) {}

//     void printTaskInfo();
// };

// class PriorityQueue
// {
// private:
//     Task *head;

//     void insertTask(Task *newTask);

// public:
//     PriorityQueue()
//         : head(nullptr) {}

//     void insert(Task task);
//     Task extractMin();
//     Task peek();
// };

// int main()
// {
//     PriorityQueue priorityQ;

//     priorityQ.insert(Task(1, 3, 5));
//     priorityQ.insert(Task(2, 1, 2));
//     priorityQ.insert(Task(3, 2, 3));
//     priorityQ.insert(Task(4, 1, 4));
//     priorityQ.insert(Task(5, 3, 1));

//     cout << "Highest priority task before extract min call" << endl;
//     priorityQ.peek().printTaskInfo();
//     priorityQ.extractMin();

//     cout << "\nHighest priority task after extract min call" << endl;
//     priorityQ.peek().printTaskInfo();

//     return 0;
// }

// void Task::printTaskInfo()
// {
//     cout << "\nTask ID: " << id << endl;
//     cout << "Execution time: " << executionTime << endl;
//     cout << "Task priority: " << priority << endl;
// }

// /*Question: How would you ensure that tasks with the highest
//  priority are executed first while maintaining the
//  integrity of the min-heap?*/

// /*Ans: Task with highest priority will be exceted first
// because we will be inserting the task will highest priority
// at head.
// */
// void PriorityQueue::insertTask(Task *newTask)
// {
//     // if priority is high make it head;
//     if (head == nullptr || newTask->priority < head->priority)
//     {
//         newTask->next = head;
//         head = newTask;
//         return;
//     }

//     // else place according to its priority;
//     Task *current = head;
//     while (current->next != nullptr && current->next->priority <= newTask->priority)
//     {
//         current = current->next;
//     }
//     newTask->next = current->next;
//     current->next = newTask;
// }

// void PriorityQueue::insert(Task task)
// {
//     Task *newTask = new Task(task.id, task.priority, task.executionTime);
//     insertTask(newTask);
// }
// /*Question: How would you handle cases where
// multiple tasks have the same priority level?*/

// /*Ans: Task at head will be the one which will be excuted 1st
// because while inserting if priority is same first come, first served
// be applied*/
// Task PriorityQueue::extractMin()
// {
//     if (head == nullptr)
//     {
//         cout << "Priority queue is empty" << endl;
//     }

//     Task temp = *head;
//     Task *newHead = head->next;
//     delete head;
//     head = newHead;
//     return temp;
// }

// Task PriorityQueue::peek()
// {
//     if (head == nullptr)
//     {
//         cout << "Priority queue is empty." << endl;
//     }
//     return *head;
// }