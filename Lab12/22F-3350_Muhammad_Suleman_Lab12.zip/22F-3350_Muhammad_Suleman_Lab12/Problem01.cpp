//#include <iostream>
//
//using namespace std;
//
//class MaxHeap
//{
//private:
//	int* heap;
//	int capacity;
//	int size;
//
//	int parent(int i)
//	{
//		return i / 2;
//	}
//
//	int left(int i)
//	{
//		return 2 * i;
//	}
//
//	int right(int i)
//	{
//		return 2 * i + 1;
//	}
//
//	void heapify(int i)
//	{
//		int l = left(i);
//		int r = right(i);
//		int smallest = i;
//
//		if (l <= size && heap[l] < heap[i])
//		{
//			smallest = l;
//		}
//		if (r <= size && heap[r] < heap[smallest])
//		{
//			smallest = r;
//		}
//		if (smallest != i)
//		{
//			swap(heap[i], heap[smallest]);
//			heapify(smallest);
//		}
//	}
//
//public:
//	MaxHeap(int cap)
//	{
//		capacity = cap;
//		size = 0;
//		heap = new int[cap + 1];
//	}
//
//	~MaxHeap() {
//		delete[] heap;
//	}
//
//	int getMin()
//	{
//		if (size == 0)
//		{
//			return numeric_limits<int>::max();
//		}
//		else
//		{
//			return heap[1];
//		}
//	}
//
//	int extractMin()
//	{
//		if (size == 0)
//		{
//			return -1;
//		}
//		int min = heap[1];
//		heap[1] = heap[size];
//		size--;
//		heapify(1);
//		return min;
//	}
//
//	void decreaseKey(int i, int new_val)
//	{
//		heap[i] = new_val;
//		while (i > 1 && heap[parent(i)] > heap[i])
//		{
//			swap(heap[i], heap[parent(i)]);
//			i = parent(i);
//		}
//	}
//
//	void insert(int key)
//	{
//		if (size == capacity)
//		{
//			return;
//		}
//		size++;
//		heap[size] = numeric_limits<int>::max();
//		decreaseKey(size, key);
//	}
//
//	void deleteKey(int i)
//	{
//		decreaseKey(i, numeric_limits<int>::min());
//		extractMin();
//	}
//};
//
//int main() {
//	int arr[] = { 10, 14, 2, 5, 33, 9, 3, 23, 73, 7 };
//
//	MaxHeap heap(10);
//
//	for (int i = 0; i < 10; i++)
//	{
//		heap.insert(arr[i]);
//	}
//
//	cout << "Minimum element: " << heap.getMin() << endl;
//	cout << "Extracted minimum: " << heap.extractMin() << endl;
//
//	heap.decreaseKey(5, 1);
//	cout << "Decreased key: " << heap.getMin() << endl;
//	heap.insert(0);
//	cout << "New minimum: " << heap.getMin() << endl;
//
//	heap.deleteKey(3);
//	cout << "Minimum after deletion: " << heap.getMin() << endl;
//
//	system("pause");
//	return 0;
//}