//#include <iostream>
//
//using namespace std;
//
//template<typename T>
//struct Node
//{
//	T data;
//	Node* left;
//	Node* right;
//
//	Node(T value)
//		: data(value), left(nullptr), right(nullptr) {}
//};
//
//template<typename T>
//class BinarySearchTree
//{
//private:
//	Node<T>* root;
//
//	void destroyTree(Node<T>* node)
//	{
//		if (node != nullptr)
//		{
//			destroyTree(node->left);
//			destroyTree(node->right);
//			delete node;
//		}
//	}
//
//	Node<T>* insert(Node<T>* root, T data)
//	{
//		if (root == nullptr)
//		{
//			Node<T>* newNode = new Node<T>(data);
//			return newNode;
//		}
//		if (data < root->data)
//		{
//			root->left = insert(root->left, data);
//		}
//		else if (data > root->data)
//		{
//			root->right = insert(root->right, data);
//		}
//		return root;
//	}
//
//	void inorderTraversal(Node<T>* root, T arr[], int& index)
//	{
//		if (root == nullptr)
//		{
//			return;
//		}
//		inorderTraversal(root->left, arr, index);
//		arr[index++] = root->data;
//		inorderTraversal(root->right, arr, index);
//	}
//
//	void preorderTraversal(Node<T>* root, T arr[], int& index)
//	{
//		if (root == nullptr)
//		{
//			return;
//		}
//		root->data = arr[index++];
//		preorderTraversal(root->left, arr, index);
//		preorderTraversal(root->right, arr, index);
//	}
//
//	void prvtPreOrder(Node<T>* root)
//	{
//		if (!root)
//		{
//			return;
//		}
//		cout << root->data << " ";
//		prvtPreOrder(root->left);
//		prvtPreOrder(root->right);
//	}
//
//public:
//	BinarySearchTree()
//		: root(nullptr) {}
//
//	~BinarySearchTree()
//	{
//		destroyTree(root);
//	}
//
//	void insert(T data)
//	{
//		root = insert(root, data);
//	}
//
//	void convertToMinHeap()
//	{
//		int size = getSize(root);
//		T* arr = new T[size];
//		int index = 0;
//		inorderTraversal(root, arr, index);
//		index = 0;
//		preorderTraversal(root, arr, index);
//		delete[] arr;
//	}
//
//	int getSize(Node<T>* node)
//	{
//		if (node == nullptr)
//			return 0;
//		return 1 + getSize(node->left) + getSize(node->right);
//	}
//
//	void preOrder()
//	{
//		prvtPreOrder(root);
//	}
//};
//
//int main()
//{
//	cout << "Convertion from BST to MinHeap" << endl;
//	BinarySearchTree<int> tree;
//	tree.insert(50);
//	tree.insert(30);
//	tree.insert(70);
//	tree.insert(20);
//	tree.insert(40);
//	tree.insert(60);
//	tree.insert(80);
//
//	cout << "Before conversion preOrder: ";
//	tree.preOrder();
//	cout << endl;
//
//	tree.convertToMinHeap();
//	
//	cout << "After conversion preOrder: ";
//	tree.preOrder();
//	cout << endl;
//
//	system("pause");
//	return 0;
//}