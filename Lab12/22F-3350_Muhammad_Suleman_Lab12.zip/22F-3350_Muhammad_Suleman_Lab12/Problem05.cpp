//#include <iostream>
//
//using namespace std;
//
//void MaxHeapify(int arr[], int i, int size)
//{
//	int l = 2 * i + 1;
//	int r = 2 * i + 2;
//	int largest = i;
//
//	if (l < size && arr[l] > arr[i])
//	{
//		largest = l;
//	}
//	if (r < size && arr[r] > arr[largest])
//	{
//		largest = r;
//	}
//	if (largest != i)
//	{
//		swap(arr[i], arr[largest]);
//		MaxHeapify(arr, largest, size);
//	}
//}
//
//void convertMaxHeap(int arr[], int size)
//{
//	for (int i = (size - 2) / 2; i >= 0; --i)
//	{
//		MaxHeapify(arr, i, size);
//	}
//}
//
//void printArray(int* arr, int size)
//{
//	for (int i = 0; i < size; ++i)
//	{
//		cout << arr[i] << " ";
//	}
//}
//
//int main()
//{
//	int arr[] = { 1,2,3,4,5,6,7,8,9,10 };
//	int n = 10;
//
//	cout << "Min Heap array : ";
//	printArray(arr, n);
//	convertMaxHeap(arr, n);
//	cout << endl;
//
//	cout << "Max Heap array : ";
//	printArray(arr, n);
//
//
//	cout << endl;
//	system("pause");
//	return 0;
//}