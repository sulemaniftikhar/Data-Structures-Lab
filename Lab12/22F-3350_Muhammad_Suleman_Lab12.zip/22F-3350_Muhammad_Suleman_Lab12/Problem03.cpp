//#include <iostream>
//
//using namespace std;
//
//void kLargest(int *arr, int n, int k)
//{
//	int *kLargest = new int[k];
//
//	for (int i = 0; i < k; i++)
//	{
//		kLargest[i] = arr[i];
//	}
//
//	for (int i = 0; i < k; i++)
//	{
//		for (int j = i + 1; j < k; j++)
//		{
//			if (kLargest[i] > kLargest[j])
//			{
//				swap(kLargest[i], kLargest[j]);
//			}
//		}
//	}
//
//	for (int i = k; i < n; i++)
//	{
//		if (arr[i] > kLargest[0])
//		{
//			kLargest[0] = arr[i];
//			for (int j = 0; j < k - 1; j++)
//			{
//				if (kLargest[j] > kLargest[j + 1])
//				{
//					swap(kLargest[j], kLargest[j + 1]);
//				}
//			}
//		}
//	}
//
//	cout << k << " largest elements are: ";
//	for (int i = k - 1; i >= 0; i--) {
//		cout << kLargest[i] << " ";
//	}
//	cout << endl;
//}
//
//int main()
//{
//	int arr[] = { 10,9,8,7,6,5,4,3,2,1 };
//	int n = 10;
//
//	cout << "Give array: ";
//	for (int i = 0; i < 10; i++)
//	{
//		cout << arr[i] << "  ";
//	}
//	cout << endl;
//
//	int k = 3;
//	kLargest(arr, n, k);
//
//	system("pause");
//	return 0;
//}